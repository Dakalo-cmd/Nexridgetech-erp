from datetime import datetime, date

from sqlalchemy import (
    String,
    Text,
    Boolean,
    Integer,
    Numeric,
    Date,
    DateTime,
    ForeignKey,
    UniqueConstraint,
)

from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


# ============================================================
# COMPANY
# ============================================================

class Company(Base):
    __tablename__ = "companies"

    id: Mapped[int] = mapped_column(primary_key=True)

    name: Mapped[str] = mapped_column(
        String(255)
    )

    trading_name: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
    )

    registration_number: Mapped[str | None] = mapped_column(
        String(64),
        nullable=True,
    )

    vat_number: Mapped[str | None] = mapped_column(
        String(32),
        nullable=True,
    )

    currency: Mapped[str] = mapped_column(
        String(8),
        default="ZAR",
    )

    country: Mapped[str] = mapped_column(
        String(64),
        default="South Africa",
    )

    fiscal_year_end: Mapped[str | None] = mapped_column(
        String(16),
        default="February",
    )

    address: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    phone: Mapped[str | None] = mapped_column(
        String(64),
        nullable=True,
    )

    email: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
    )

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        default=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
    )


# ============================================================
# USER
# ============================================================

class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    email: Mapped[str] = mapped_column(
        String(255),
        unique=True,
    )

    password_hash: Mapped[str] = mapped_column(
        String(255)
    )

    full_name: Mapped[str] = mapped_column(
        String(255)
    )

    role: Mapped[str] = mapped_column(
        String(64),
        default="admin",
    )

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        default=True,
    )

    last_login: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
    )


# ============================================================
# COMPANY USERS
# ============================================================

class CompanyUser(Base):
    __tablename__ = "company_users"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    company_id: Mapped[int] = mapped_column(
        ForeignKey(
            "companies.id",
            ondelete="CASCADE",
        )
    )

    user_id: Mapped[int] = mapped_column(
        ForeignKey(
            "users.id",
            ondelete="CASCADE",
        )
    )

    role: Mapped[str] = mapped_column(
        String(64),
        default="admin",
    )

    __table_args__ = (
        UniqueConstraint(
            "company_id",
            "user_id",
        ),
    )


# ============================================================
# CHART OF ACCOUNTS
# ============================================================

class Account(Base):
    __tablename__ = "accounts"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    company_id: Mapped[int] = mapped_column(
        ForeignKey(
            "companies.id",
            ondelete="CASCADE",
        )
    )

    code: Mapped[str] = mapped_column(
        String(32)
    )

    name: Mapped[str] = mapped_column(
        String(255)
    )

    account_type: Mapped[str] = mapped_column(
        String(64)
    )

    sub_type: Mapped[str | None] = mapped_column(
        String(128),
        nullable=True,
    )

    tax_code: Mapped[str | None] = mapped_column(
        String(64),
        default="No VAT",
    )

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        default=True,
    )

    cost_centre_required: Mapped[bool] = mapped_column(
        Boolean,
        default=False,
    )

    project_required: Mapped[bool] = mapped_column(
        Boolean,
        default=False,
    )

    balance: Mapped[float] = mapped_column(
        Numeric(18, 2),
        default=0,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
    )

    __table_args__ = (
        UniqueConstraint(
            "company_id",
            "code",
        ),
    )


# ============================================================
# JOURNAL
# ============================================================

class Journal(Base):
    __tablename__ = "journals"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    company_id: Mapped[int] = mapped_column(
        ForeignKey(
            "companies.id",
            ondelete="CASCADE",
        )
    )

    journal_number: Mapped[str] = mapped_column(
        String(64)
    )

    journal_date: Mapped[date] = mapped_column(
        Date
    )

    reference: Mapped[str | None] = mapped_column(
        String(128),
        nullable=True,
    )

    description: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    status: Mapped[str] = mapped_column(
        String(32),
        default="Draft",
    )

    created_by: Mapped[int | None] = mapped_column(
        ForeignKey("users.id"),
        nullable=True,
    )

    posted_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
    )

    lines: Mapped[list["JournalLine"]] = relationship(
        back_populates="journal",
        cascade="all, delete-orphan",
    )

    __table_args__ = (
        UniqueConstraint(
            "company_id",
            "journal_number",
        ),
    )


# ============================================================
# JOURNAL LINE
# ============================================================

class JournalLine(Base):
    __tablename__ = "journal_lines"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    journal_id: Mapped[int] = mapped_column(
        ForeignKey(
            "journals.id",
            ondelete="CASCADE",
        )
    )

    account_id: Mapped[int | None] = mapped_column(
        ForeignKey("accounts.id"),
        nullable=True,
    )

    account_code: Mapped[str | None] = mapped_column(
        String(32),
        nullable=True,
    )

    description: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    debit: Mapped[float] = mapped_column(
        Numeric(18, 2),
        default=0,
    )

    credit: Mapped[float] = mapped_column(
        Numeric(18, 2),
        default=0,
    )

    line_order: Mapped[int] = mapped_column(
        Integer,
        default=0,
    )

    journal: Mapped["Journal"] = relationship(
        back_populates="lines"
    )


# ============================================================
# CUSTOMER
# ============================================================

class Customer(Base):
    __tablename__ = "customers"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    company_id: Mapped[int] = mapped_column(
        ForeignKey(
            "companies.id",
            ondelete="CASCADE",
        )
    )

    code: Mapped[str | None] = mapped_column(
        String(32),
        nullable=True,
    )

    name: Mapped[str] = mapped_column(
        String(255)
    )

    registration_number: Mapped[str | None] = mapped_column(
        String(64),
        nullable=True,
    )

    vat_number: Mapped[str | None] = mapped_column(
        String(32),
        nullable=True,
    )

    contact_name: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
    )

    email: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
    )

    phone: Mapped[str | None] = mapped_column(
        String(64),
        nullable=True,
    )

    payment_terms: Mapped[str | None] = mapped_column(
        String(64),
        default="30 Days",
    )

    credit_limit: Mapped[float] = mapped_column(
        Numeric(18, 2),
        default=0,
    )

    balance: Mapped[float] = mapped_column(
        Numeric(18, 2),
        default=0,
    )

    overdue: Mapped[float] = mapped_column(
        Numeric(18, 2),
        default=0,
    )

    address: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        default=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
    )


# ============================================================
# SUPPLIER
# ============================================================

class Supplier(Base):
    __tablename__ = "suppliers"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    company_id: Mapped[int] = mapped_column(
        ForeignKey(
            "companies.id",
            ondelete="CASCADE",
        )
    )

    code: Mapped[str | None] = mapped_column(
        String(32),
        nullable=True,
    )

    name: Mapped[str] = mapped_column(
        String(255)
    )

    registration_number: Mapped[str | None] = mapped_column(
        String(64),
        nullable=True,
    )

    vat_number: Mapped[str | None] = mapped_column(
        String(32),
        nullable=True,
    )

    contact_name: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
    )

    email: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
    )

    phone: Mapped[str | None] = mapped_column(
        String(64),
        nullable=True,
    )

    payment_terms: Mapped[str | None] = mapped_column(
        String(64),
        default="30 Days",
    )

    balance: Mapped[float] = mapped_column(
        Numeric(18, 2),
        default=0,
    )

    overdue: Mapped[float] = mapped_column(
        Numeric(18, 2),
        default=0,
    )

    address: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        default=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
    )


# ============================================================
# QUOTE
# ============================================================

class Quote(Base):
    __tablename__ = "quotes"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    company_id: Mapped[int] = mapped_column(
        ForeignKey(
            "companies.id",
            ondelete="CASCADE",
        )
    )

    customer_id: Mapped[int] = mapped_column(
        ForeignKey("customers.id")
    )

    quote_number: Mapped[str] = mapped_column(
        String(64)
    )

    quote_date: Mapped[date] = mapped_column(
        Date
    )

    valid_until: Mapped[date | None] = mapped_column(
        Date,
        nullable=True,
    )

    subtotal: Mapped[float] = mapped_column(
        Numeric(18, 2),
        default=0,
    )

    vat_amount: Mapped[float] = mapped_column(
        Numeric(18, 2),
        default=0,
    )

    total: Mapped[float] = mapped_column(
        Numeric(18, 2),
        default=0,
    )

    status: Mapped[str] = mapped_column(
        String(32),
        default="Draft",
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
    )

    lines: Mapped[list["QuoteLine"]] = relationship(
        back_populates="quote",
        cascade="all, delete-orphan",
    )

    __table_args__ = (
        UniqueConstraint(
            "company_id",
            "quote_number",
        ),
    )


# ============================================================
# QUOTE LINE
# ============================================================

class QuoteLine(Base):
    __tablename__ = "quote_lines"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    quote_id: Mapped[int] = mapped_column(
        ForeignKey(
            "quotes.id",
            ondelete="CASCADE",
        )
    )

    description: Mapped[str] = mapped_column(
        Text
    )

    quantity: Mapped[float] = mapped_column(
        Numeric(18, 4),
        default=1,
    )

    unit_price: Mapped[float] = mapped_column(
        Numeric(18, 2),
        default=0,
    )

    vat_rate: Mapped[float] = mapped_column(
        Numeric(8, 2),
        default=15,
    )

    discount_percent: Mapped[float] = mapped_column(
        Numeric(8, 2),
        default=0,
    )

    line_order: Mapped[int] = mapped_column(
        Integer,
        default=0,
    )

    quote: Mapped["Quote"] = relationship(
        back_populates="lines"
    )


# ============================================================
# SALES ORDER
# ============================================================

class SalesOrder(Base):
    __tablename__ = "sales_orders"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    company_id: Mapped[int] = mapped_column(
        ForeignKey(
            "companies.id",
            ondelete="CASCADE",
        )
    )

    customer_id: Mapped[int] = mapped_column(
        ForeignKey("customers.id")
    )

    order_number: Mapped[str] = mapped_column(
        String(64)
    )

    order_date: Mapped[date] = mapped_column(
        Date
    )

    delivery_date: Mapped[date | None] = mapped_column(
        Date,
        nullable=True,
    )

    subtotal: Mapped[float] = mapped_column(
        Numeric(18, 2),
        default=0,
    )

    vat_amount: Mapped[float] = mapped_column(
        Numeric(18, 2),
        default=0,
    )

    total: Mapped[float] = mapped_column(
        Numeric(18, 2),
        default=0,
    )

    status: Mapped[str] = mapped_column(
        String(32),
        default="Draft",
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
    )

    lines: Mapped[list["SalesOrderLine"]] = relationship(
        back_populates="order",
        cascade="all, delete-orphan",
    )

    __table_args__ = (
        UniqueConstraint(
            "company_id",
            "order_number",
        ),
    )


# ============================================================
# SALES ORDER LINE
# ============================================================

class SalesOrderLine(Base):
    __tablename__ = "sales_order_lines"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    sales_order_id: Mapped[int] = mapped_column(
        ForeignKey(
            "sales_orders.id",
            ondelete="CASCADE",
        )
    )

    description: Mapped[str] = mapped_column(
        Text
    )

    quantity: Mapped[float] = mapped_column(
        Numeric(18, 4),
        default=1,
    )

    unit_price: Mapped[float] = mapped_column(
        Numeric(18, 2),
        default=0,
    )

    vat_rate: Mapped[float] = mapped_column(
        Numeric(8, 2),
        default=15,
    )

    discount_percent: Mapped[float] = mapped_column(
        Numeric(8, 2),
        default=0,
    )

    line_order: Mapped[int] = mapped_column(
        Integer,
        default=0,
    )

    order: Mapped["SalesOrder"] = relationship(
        back_populates="lines"
    )


# ============================================================
# INVOICE
# ============================================================

class Invoice(Base):
    __tablename__ = "invoices"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    company_id: Mapped[int] = mapped_column(
        ForeignKey(
            "companies.id",
            ondelete="CASCADE",
        )
    )

    customer_id: Mapped[int] = mapped_column(
        ForeignKey("customers.id")
    )

    invoice_number: Mapped[str] = mapped_column(
        String(64)
    )

    invoice_date: Mapped[date] = mapped_column(
        Date
    )

    due_date: Mapped[date | None] = mapped_column(
        Date,
        nullable=True,
    )

    description: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    subtotal: Mapped[float] = mapped_column(
        Numeric(18, 2),
        default=0,
    )

    vat_amount: Mapped[float] = mapped_column(
        Numeric(18, 2),
        default=0,
    )

    total: Mapped[float] = mapped_column(
        Numeric(18, 2),
        default=0,
    )

    amount_paid: Mapped[float] = mapped_column(
        Numeric(18, 2),
        default=0,
    )

    status: Mapped[str] = mapped_column(
        String(32),
        default="Draft",
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
    )

    posted_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True,
    )

    lines: Mapped[list["InvoiceLine"]] = relationship(
        back_populates="invoice",
        cascade="all, delete-orphan",
    )

    __table_args__ = (
        UniqueConstraint(
            "company_id",
            "invoice_number",
        ),
    )


# ============================================================
# INVOICE LINE
# ============================================================

class InvoiceLine(Base):
    __tablename__ = "invoice_lines"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    invoice_id: Mapped[int] = mapped_column(
        ForeignKey(
            "invoices.id",
            ondelete="CASCADE",
        )
    )

    description: Mapped[str] = mapped_column(
        Text
    )

    quantity: Mapped[float] = mapped_column(
        Numeric(18, 4),
        default=1,
    )

    unit_price: Mapped[float] = mapped_column(
        Numeric(18, 2),
        default=0,
    )

    vat_rate: Mapped[float] = mapped_column(
        Numeric(8, 2),
        default=15,
    )

    discount_percent: Mapped[float] = mapped_column(
        Numeric(8, 2),
        default=0,
    )

    line_order: Mapped[int] = mapped_column(
        Integer,
        default=0,
    )

    invoice: Mapped["Invoice"] = relationship(
        back_populates="lines"
    )


# ============================================================
# CUSTOMER RECEIPT
# ============================================================
#
# Accounting flow:
#
#   Customer pays invoice
#
#   DR  Bank
#   CR  Accounts Receivable
#
# The Receipt represents the money received.
# ReceiptAllocation connects the receipt to one or more invoices.
#

class Receipt(Base):
    __tablename__ = "receipts"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    company_id: Mapped[int] = mapped_column(
        ForeignKey(
            "companies.id",
            ondelete="CASCADE",
        )
    )

    customer_id: Mapped[int] = mapped_column(
        ForeignKey("customers.id")
    )

    receipt_number: Mapped[str] = mapped_column(
        String(64)
    )

    receipt_date: Mapped[date] = mapped_column(
        Date
    )

    reference: Mapped[str | None] = mapped_column(
        String(128),
        nullable=True,
    )

    description: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    amount: Mapped[float] = mapped_column(
        Numeric(18, 2),
        default=0,
    )

    bank_account_id: Mapped[int] = mapped_column(
        ForeignKey("accounts.id")
    )

    status: Mapped[str] = mapped_column(
        String(32),
        default="Draft",
    )

    created_by: Mapped[int | None] = mapped_column(
        ForeignKey("users.id"),
        nullable=True,
    )

    posted_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
    )

    allocations: Mapped[list["ReceiptAllocation"]] = relationship(
        back_populates="receipt",
        cascade="all, delete-orphan",
    )

    __table_args__ = (
        UniqueConstraint(
            "company_id",
            "receipt_number",
        ),
    )


# ============================================================
# CUSTOMER RECEIPT ALLOCATION
# ============================================================
#
# Example:
#
# Receipt = R1,150
#
# Allocation:
#   Invoice INV-20261008-0001 = R1,150
#
# This allows one receipt to pay multiple invoices as well.
#

class ReceiptAllocation(Base):
    __tablename__ = "receipt_allocations"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    receipt_id: Mapped[int] = mapped_column(
        ForeignKey(
            "receipts.id",
            ondelete="CASCADE",
        )
    )

    invoice_id: Mapped[int] = mapped_column(
        ForeignKey("invoices.id")
    )

    amount: Mapped[float] = mapped_column(
        Numeric(18, 2),
        default=0,
    )

    receipt: Mapped["Receipt"] = relationship(
        back_populates="allocations"
    )

    invoice: Mapped["Invoice"] = relationship()


# ============================================================
# DOCUMENT SEQUENCES
# ============================================================

class DocumentSequence(Base):
    __tablename__ = "document_sequences"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    company_id: Mapped[int] = mapped_column(
        ForeignKey(
            "companies.id",
            ondelete="CASCADE",
        )
    )

    doc_type: Mapped[str] = mapped_column(
        String(64)
    )

    prefix: Mapped[str] = mapped_column(
        String(32)
    )

    next_number: Mapped[int] = mapped_column(
        Integer,
        default=1,
    )

    __table_args__ = (
        UniqueConstraint(
            "company_id",
            "doc_type",
        ),
    )