from datetime import date, datetime
from pydantic import BaseModel
from typing import Optional, List


# ============================================================
# AUTH
# ============================================================

class LoginIn(BaseModel):
    email: str
    password: str


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    company_id: int
    company_name: str
    user_id: int
    email: str
    full_name: str
    role: str


# ============================================================
# LINES
# ============================================================

class LineIn(BaseModel):
    description: str = "Line item"
    quantity: float = 1
    unit_price: float = 0
    vat_rate: float = 15
    discount_percent: float = 0
    line_order: int = 0


class LineOut(BaseModel):
    id: int
    description: str
    quantity: float
    unit_price: float
    vat_rate: float
    discount_percent: float
    line_order: int

    class Config:
        from_attributes = True


# ============================================================
# CUSTOMERS
# ============================================================

class CustomerIn(BaseModel):
    company_id: Optional[int] = None
    name: str
    registration_number: Optional[str] = None
    vat_number: Optional[str] = None
    contact_name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    payment_terms: Optional[str] = "30 Days"
    credit_limit: float = 0
    address: Optional[str] = None


class CustomerOut(BaseModel):
    id: int
    company_id: int
    code: Optional[str] = None
    name: str
    registration_number: Optional[str] = None
    vat_number: Optional[str] = None
    contact_name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    payment_terms: Optional[str] = None
    credit_limit: float = 0
    balance: float = 0
    overdue: float = 0
    address: Optional[str] = None

    class Config:
        from_attributes = True


# ============================================================
# ACCOUNTS
# ============================================================

class AccountIn(BaseModel):
    company_id: Optional[int] = None
    code: str
    name: str
    account_type: Optional[str] = None
    type: Optional[str] = None
    sub_type: Optional[str] = None
    tax_code: Optional[str] = "No VAT"
    is_active: bool = True
    active: Optional[bool] = None
    cost_centre_required: bool = False
    project_required: bool = False


class AccountOut(BaseModel):
    id: int
    company_id: int
    code: str
    name: str
    account_type: str
    type: Optional[str] = None
    sub_type: Optional[str] = None
    tax_code: Optional[str] = None
    is_active: bool = True
    active: Optional[bool] = None
    cost_centre_required: bool = False
    project_required: bool = False
    balance: float = 0

    class Config:
        from_attributes = True


# ============================================================
# JOURNALS
# ============================================================

class JournalLineIn(BaseModel):
    account_id: Optional[int] = None
    account_code: Optional[str] = None
    account: Optional[str] = None
    description: Optional[str] = None
    debit: float = 0
    credit: float = 0
    line_order: int = 0


class JournalIn(BaseModel):
    company_id: Optional[int] = None
    journal_date: Optional[date] = None
    date: Optional[date] = None
    reference: Optional[str] = None
    description: Optional[str] = None
    status: str = "Draft"
    lines: List[JournalLineIn] = []


class JournalLineOut(BaseModel):
    id: int
    account_id: Optional[int] = None
    account_code: Optional[str] = None
    description: Optional[str] = None
    debit: float = 0
    credit: float = 0
    line_order: int = 0

    class Config:
        from_attributes = True


class JournalOut(BaseModel):
    id: int
    company_id: int
    journal_number: str
    journal_date: date
    reference: Optional[str] = None
    description: Optional[str] = None
    status: str
    lines: List[JournalLineOut] = []

    class Config:
        from_attributes = True


# ============================================================
# QUOTES
# ============================================================

class QuoteIn(BaseModel):
    company_id: Optional[int] = None
    customer_id: int
    quote_date: Optional[date] = None
    valid_until: Optional[date] = None
    status: str = "Draft"
    lines: List[LineIn] = []


class QuoteOut(BaseModel):
    id: int
    company_id: int
    customer_id: int
    quote_number: str
    quote_date: date
    valid_until: Optional[date] = None
    subtotal: float
    vat_amount: float
    total: float
    status: str
    lines: List[LineOut] = []

    class Config:
        from_attributes = True


# ============================================================
# SALES ORDERS
# ============================================================

class SalesOrderIn(BaseModel):
    company_id: Optional[int] = None
    customer_id: int
    order_date: Optional[date] = None
    delivery_date: Optional[date] = None
    status: str = "Draft"
    lines: List[LineIn] = []


class SalesOrderOut(BaseModel):
    id: int
    company_id: int
    customer_id: int
    order_number: str
    order_date: date
    delivery_date: Optional[date] = None
    subtotal: float
    vat_amount: float
    total: float
    status: str
    lines: List[LineOut] = []

    class Config:
        from_attributes = True


# ============================================================
# INVOICES
# ============================================================

class InvoiceIn(BaseModel):
    company_id: Optional[int] = None
    customer_id: int
    invoice_date: Optional[date] = None
    due_date: Optional[date] = None
    description: Optional[str] = None
    status: str = "Draft"
    lines: List[LineIn] = []


class InvoiceOut(BaseModel):
    id: int
    company_id: int
    customer_id: int
    invoice_number: str
    invoice_date: date
    due_date: Optional[date] = None
    description: Optional[str] = None
    subtotal: float
    vat_amount: float
    total: float
    amount_paid: float = 0
    paid: Optional[float] = None
    status: str
    lines: List[LineOut] = []

    class Config:
        from_attributes = True


# ============================================================
# RECEIPTS / CUSTOMER PAYMENTS
# ============================================================

class ReceiptAllocationIn(BaseModel):
    invoice_id: int
    amount: float


class ReceiptIn(BaseModel):
    company_id: Optional[int] = None
    customer_id: int
    receipt_date: Optional[date] = None
    reference: Optional[str] = None
    description: Optional[str] = None
    amount: float
    bank_account_id: Optional[int] = None
    status: str = "Draft"
    allocations: List[ReceiptAllocationIn] = []


class ReceiptAllocationOut(BaseModel):
    id: int
    invoice_id: int
    amount: float

    class Config:
        from_attributes = True


class ReceiptOut(BaseModel):
    id: int
    company_id: int
    customer_id: int
    receipt_number: str
    receipt_date: date
    reference: Optional[str] = None
    description: Optional[str] = None
    amount: float
    bank_account_id: int
    status: str
    allocations: List[ReceiptAllocationOut] = []

    class Config:
        from_attributes = True


# ============================================================
# COMPANY
# ============================================================

class CompanyOut(BaseModel):
    id: int
    name: str
    registration_number: Optional[str] = None
    vat_number: Optional[str] = None
    currency: str = "ZAR"

    class Config:
        from_attributes = True