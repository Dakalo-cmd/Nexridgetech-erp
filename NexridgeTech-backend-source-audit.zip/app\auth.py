from datetime import datetime, timedelta
from typing import Optional

from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import jwt, JWTError
from passlib.context import CryptContext
from sqlalchemy.orm import Session

from app.config import get_settings
from app.database import get_db
from app import models


pwd_context = CryptContext(
    schemes=["bcrypt"],
    deprecated="auto",
)

security = HTTPBearer(auto_error=False)

settings = get_settings()


def hash_password(password: str) -> str:
    """
    Hash a plain-text password using bcrypt.
    """
    return pwd_context.hash(password)


def verify_password(plain: str, hashed: str) -> bool:
    """
    Verify a plain-text password against a stored bcrypt hash.
    """
    return pwd_context.verify(plain, hashed)


def create_access_token(
    data: dict,
    expires_minutes: Optional[int] = None,
) -> str:
    """
    Create a JWT access token.
    """
    to_encode = data.copy()

    expire = datetime.utcnow() + timedelta(
        minutes=expires_minutes or settings.access_token_expire_minutes
    )

    to_encode.update(
        {
            "exp": expire,
        }
    )

    return jwt.encode(
        to_encode,
        settings.secret_key,
        algorithm=settings.algorithm,
    )


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db),
) -> models.User:
    """
    Authenticate the current user from the Authorization bearer token.

    The user's selected company from the JWT is attached to the user object
    so other endpoints can determine the active company.
    """

    if not credentials:
        raise HTTPException(
            status_code=401,
            detail="Not authenticated",
        )

    token = credentials.credentials

    try:
        payload = jwt.decode(
            token,
            settings.secret_key,
            algorithms=[settings.algorithm],
        )

        user_id = int(payload.get("sub"))
        company_id = payload.get("company_id")

    except (JWTError, TypeError, ValueError):
        raise HTTPException(
            status_code=401,
            detail="Invalid or expired token",
        )

    user = db.get(models.User, user_id)

    if not user or not user.is_active:
        raise HTTPException(
            status_code=401,
            detail="User not found or inactive",
        )

    # Store the company from the authenticated token on the user object.
    user._token_company_id = company_id  # type: ignore[attr-defined]

    return user


def require_company_id(
    user: models.User,
    company_id: Optional[int] = None,
    db: Optional[Session] = None,
) -> int:
    """
    Resolve and authorize the company used by the current request.

    If company_id is supplied by the request, the current user must belong
    to that company.

    If company_id is not supplied, the company from the authenticated
    login token is used.

    This prevents a user from accessing another company's data simply
    by changing the company_id in the request.
    """

    token_company_id = getattr(
        user,
        "_token_company_id",
        None,
    )

    # Use explicitly supplied company_id first.
    # Otherwise use the company stored in the authenticated JWT.
    cid = company_id if company_id is not None else token_company_id

    if cid is None:
        raise HTTPException(
            status_code=400,
            detail="company_id is required",
        )

    try:
        cid = int(cid)
    except (TypeError, ValueError):
        raise HTTPException(
            status_code=400,
            detail="Invalid company_id",
        )

    if cid <= 0:
        raise HTTPException(
            status_code=400,
            detail="Invalid company_id",
        )

    if db is None:
        raise HTTPException(
            status_code=500,
            detail="Database session is required for company authorization",
        )

    # Verify that the authenticated user actually belongs to this company.
    membership = (
        db.query(models.CompanyUser)
        .filter(
            models.CompanyUser.company_id == cid,
            models.CompanyUser.user_id == user.id,
        )
        .first()
    )

    if not membership:
        raise HTTPException(
            status_code=403,
            detail="You do not have access to this company",
        )

    return cid