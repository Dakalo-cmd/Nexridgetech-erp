from datetime import date, datetime
from typing import List, Optional

from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session, joinedload

from app.config import get_settings
from app.database import Base, engine, get_db, SessionLocal
from app import models, schemas
from app.auth import (
    verify_password,
    hash_password,
    create_access_token,
    get_current_user,
    require_company_id,
)
from app.services import (
    next_doc_number,
    line_totals,
    resolve_account,
    apply_journal_balances,
)


settings = get_settings()


# ============================================================
# APPLICATION
# ============================================================

app = FastAPI(
    title="NexridgeTech Accounting & ERP API",
    version="1.0.0",
)


origins = [
    o.strip()
    for o in settings.cors_origins.split(",")
    if o.strip()
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins if origins != ["*"] else ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============================================================
# DOCUMENT SEQUENCES
# ============================================================

REQUIRED_DOCUMENT_SEQUENCES = [
    ("quote", "QT"),
    ("invoice", "INV"),
    ("journal", "JE"),
    ("sales_order", "SO"),
    ("bill", "BILL"),
    ("po", "PO"),
    ("receipt", "RCPT"),
]


def ensure_document_sequences(db: Session):
    """
    Ensure every company has the required document sequences.

    Existing sequence counters are never reset.
    Missing sequences are created only when necessary.
    """

    companies = db.query(models.Company).all()

    changed = False

    for company in companies:

        for doc_type, prefix in REQUIRED_DOCUMENT_SEQUENCES:

            existing = (
                db.query(models.DocumentSequence)
                .filter(
                    models.DocumentSequence.company_id == company.id,
                    models.DocumentSequence.doc_type == doc_type,
                )
                .first()
            )

            if not existing:

                db.add(
                    models.DocumentSequence(
                        company_id=company.id,
                        doc_type=doc_type,
                        prefix=prefix,
                        next_number=1,
                    )
                )

                changed = True

    if changed:
        db.commit()


# ============================================================
# DATABASE SEED
# ============================================================

def seed_if_empty():

    Base.metadata.create_all(bind=engine)

    db = SessionLocal()

    try:

        if db.query(models.Company).count() == 0:

            company = models.Company(
                name="NexridgeTech IT Solutions",
                trading_name="NexridgeTech",
                registration_number="2018/123456/07",
                vat_number="4120123456",
                currency="ZAR",
            )

            db.add(company)
            db.flush()

            user = models.User(
                email="admin@nexridgetech.co.za",
                password_hash=hash_password("admin123"),
                full_name="J. Steenkamp",
                role="admin",
            )

            db.add(user)
            db.flush()

            db.add(
                models.CompanyUser(
                    company_id=company.id,
                    user_id=user.id,
                    role="admin",
                )
            )

            default_accounts = [
                (
                    "1000",
                    "Bank – FNB Business Cheque",
                    "Assets",
                    "Current Assets",
                ),
                (
                    "1100",
                    "Accounts Receivable Control",
                    "Assets",
                    "Current Assets",
                ),
                (
                    "1300",
                    "VAT Input Control",
                    "Assets",
                    "Current Assets",
                ),
                (
                    "2000",
                    "Accounts Payable Control",
                    "Liabilities",
                    "Current Liabilities",
                ),
                (
                    "2100",
                    "VAT Output Control",
                    "Liabilities",
                    "Current Liabilities",
                ),
                (
                    "3000",
                    "Share Capital",
                    "Equity",
                    "Equity",
                ),
                (
                    "3100",
                    "Retained Earnings",
                    "Equity",
                    "Equity",
                ),
                (
                    "4000",
                    "Sales / Service Revenue",
                    "Revenue",
                    "Operating Revenue",
                ),
                (
                    "5000",
                    "Cost of Sales",
                    "Cost of Sales",
                    "Cost of Sales",
                ),
                (
                    "6000",
                    "Salaries and Wages",
                    "Expenses",
                    "Operating Expenses",
                ),
                (
                    "6010",
                    "Office Expenses",
                    "Expenses",
                    "Operating Expenses",
                ),
                (
                    "6020",
                    "Telephone and Internet",
                    "Expenses",
                    "Operating Expenses",
                ),
                (
                    "6080",
                    "Cloud Hosting and Software",
                    "Expenses",
                    "Operating Expenses",
                ),
                (
                    "6100",
                    "Repairs and Maintenance",
                    "Expenses",
                    "Operating Expenses",
                ),
            ]

            for code, name, atype, sub in default_accounts:

                db.add(
                    models.Account(
                        company_id=company.id,
                        code=code,
                        name=name,
                        account_type=atype,
                        sub_type=sub,
                        tax_code="No VAT",
                        is_active=True,
                    )
                )

            for doc_type, prefix in REQUIRED_DOCUMENT_SEQUENCES:

                db.add(
                    models.DocumentSequence(
                        company_id=company.id,
                        doc_type=doc_type,
                        prefix=prefix,
                        next_number=1,
                    )
                )

            db.commit()

            print(
                "[Nexridge] Seeded default company, admin user and chart of accounts."
            )

        ensure_document_sequences(db)

    finally:
        db.close()


@app.on_event("startup")
def on_startup():
    seed_if_empty()


# ============================================================
# ROOT / HEALTH
# ============================================================

@app.get("/")
def root():
    return {
        "name": "NexridgeTech ERP API",
        "version": "1.0.0",
        "status": "ok",
    }


@app.get("/health")
def health():
    return {
        "status": "healthy"
    }


# ============================================================
# AUTH
# ============================================================

@app.post(
    "/api/v1/auth/login",
    response_model=schemas.TokenOut,
)
def login(
    body: schemas.LoginIn,
    db: Session = Depends(get_db),
):

    email = body.email.strip().lower()

    user = (
        db.query(models.User)
        .filter(
            models.User.email == email
        )
        .first()
    )

    if not user:

        user = (
            db.query(models.User)
            .filter(
                models.User.email == body.email.strip()
            )
            .first()
        )

    if not user:

        raise HTTPException(
            status_code=401,
            detail="Invalid email or password",
        )

    if not user.is_active:

        raise HTTPException(
            status_code=401,
            detail="User account is inactive",
        )

    if not verify_password(
        body.password,
        user.password_hash,
    ):

        raise HTTPException(
            status_code=401,
            detail="Invalid email or password",
        )

    membership = (
        db.query(models.CompanyUser)
        .filter(
            models.CompanyUser.user_id == user.id
        )
        .first()
    )

    if not membership:

        raise HTTPException(
            status_code=403,
            detail="User is not linked to a company",
        )

    company = db.get(
        models.Company,
        membership.company_id,
    )

    if not company:

        raise HTTPException(
            status_code=404,
            detail="Company not found",
        )

    user.last_login = datetime.utcnow()

    db.commit()

    token = create_access_token(
        {
            "sub": str(user.id),
            "company_id": company.id,
            "role": user.role,
            "email": user.email,
            "full_name": user.full_name,
        }
    )

    return {
        "access_token": token,
        "token_type": "bearer",
        "company_id": company.id,
        "company_name": company.name,
        "user_id": user.id,
        "email": user.email,
        "full_name": user.full_name,
        "role": user.role,
    }


@app.get("/api/v1/auth/me")
def me(
    user: models.User = Depends(get_current_user),
):

    return {
        "id": user.id,
        "email": user.email,
        "full_name": user.full_name,
        "role": user.role,
        "is_active": user.is_active,
    }


# ============================================================
# COMPANIES
# ============================================================

@app.get(
    "/api/v1/companies",
    response_model=List[schemas.CompanyOut],
)
def list_companies(
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    companies = (
        db.query(models.Company)
        .join(
            models.CompanyUser,
            models.CompanyUser.company_id == models.Company.id,
        )
        .filter(
            models.CompanyUser.user_id == user.id
        )
        .all()
    )

    return companies


# ============================================================
# CUSTOMERS
# ============================================================

@app.get(
    "/api/v1/customers",
    response_model=List[schemas.CustomerOut],
)
def list_customers(
    company_id: int,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    cid = require_company_id(
        user,
        company_id,
        db,
    )

    return (
        db.query(models.Customer)
        .filter(
            models.Customer.company_id == cid
        )
        .order_by(
            models.Customer.id.desc()
        )
        .all()
    )


@app.post(
    "/api/v1/customers",
    response_model=schemas.CustomerOut,
)
def create_customer(
    body: schemas.CustomerIn,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    cid = require_company_id(
        user,
        body.company_id,
        db,
    )

    customer = models.Customer(
        company_id=cid,
        code=(
            f"CUS-"
            f"{db.query(models.Customer).filter_by(company_id=cid).count() + 1:04d}"
        ),
        name=body.name,
        registration_number=body.registration_number,
        vat_number=body.vat_number,
        contact_name=body.contact_name,
        email=body.email,
        phone=body.phone,
        payment_terms=body.payment_terms,
        credit_limit=body.credit_limit,
        address=body.address,
        balance=0,
    )

    db.add(customer)
    db.commit()
    db.refresh(customer)

    return customer


# ============================================================
# ACCOUNTS
# ============================================================

def account_to_out(account):

    return {
        "id": account.id,
        "company_id": account.company_id,
        "code": account.code,
        "name": account.name,
        "account_type": account.account_type,
        "type": account.account_type,
        "sub_type": account.sub_type,
        "tax_code": account.tax_code,
        "is_active": account.is_active,
        "active": account.is_active,
        "cost_centre_required": account.cost_centre_required,
        "project_required": account.project_required,
        "balance": float(account.balance or 0),
    }


@app.get("/api/v1/accounts")
def list_accounts(
    company_id: int,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    cid = require_company_id(
        user,
        company_id,
        db,
    )

    accounts = (
        db.query(models.Account)
        .filter(
            models.Account.company_id == cid
        )
        .order_by(
            models.Account.code
        )
        .all()
    )

    return [
        account_to_out(account)
        for account in accounts
    ]


@app.post("/api/v1/accounts")
def create_account(
    body: schemas.AccountIn,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    cid = require_company_id(
        user,
        body.company_id,
        db,
    )

    account_type = (
        body.account_type
        or body.type
        or "Assets"
    )

    account = models.Account(
        company_id=cid,
        code=body.code,
        name=body.name,
        account_type=account_type,
        sub_type=body.sub_type,
        tax_code=body.tax_code,
        is_active=(
            body.active
            if body.active is not None
            else body.is_active
        ),
        cost_centre_required=body.cost_centre_required,
        project_required=body.project_required,
    )

    db.add(account)
    db.commit()
    db.refresh(account)

    return account_to_out(account)


@app.patch("/api/v1/accounts/{account_id}")
def update_account(
    account_id: int,
    body: schemas.AccountIn,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    cid = require_company_id(
        user,
        body.company_id,
        db,
    )

    account = (
        db.query(models.Account)
        .filter(
            models.Account.id == account_id,
            models.Account.company_id == cid,
        )
        .first()
    )

    if not account:

        raise HTTPException(
            status_code=404,
            detail="Account not found",
        )

    account.code = body.code
    account.name = body.name
    account.account_type = (
        body.account_type
        or body.type
        or account.account_type
    )
    account.sub_type = body.sub_type
    account.tax_code = body.tax_code

    if body.active is not None:
        account.is_active = body.active
    else:
        account.is_active = body.is_active

    account.cost_centre_required = body.cost_centre_required
    account.project_required = body.project_required

    db.commit()
    db.refresh(account)

    return account_to_out(account)


# ============================================================
# JOURNALS
# ============================================================

def journal_to_out(journal):

    lines = sorted(
        list(journal.lines or []),
        key=lambda line: (
            int(line.line_order or 0),
            int(line.id or 0),
        ),
    )

    return {
        "id": journal.id,
        "company_id": journal.company_id,
        "journal_number": journal.journal_number,
        "journal_date": (
            journal.journal_date.isoformat()
            if journal.journal_date
            else None
        ),
        "reference": journal.reference,
        "description": journal.description,
        "status": journal.status,
        "created_by": getattr(
            journal,
            "created_by",
            None,
        ),
        "posted_at": (
            journal.posted_at.isoformat()
            if getattr(journal, "posted_at", None)
            else None
        ),
        "created_at": (
            journal.created_at.isoformat()
            if getattr(journal, "created_at", None)
            else None
        ),
        "lines": [
            {
                "id": line.id,
                "account_id": line.account_id,
                "account_code": line.account_code,
                "account": line.account_code,
                "description": line.description,
                "debit": float(line.debit or 0),
                "credit": float(line.credit or 0),
                "line_order": line.line_order,
            }
            for line in lines
        ],
    }


@app.get("/api/v1/journals")
def list_journals(
    company_id: int,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    cid = require_company_id(
        user,
        company_id,
        db,
    )

    journals = (
        db.query(models.Journal)
        .options(
            joinedload(models.Journal.lines)
        )
        .filter(
            models.Journal.company_id == cid
        )
        .order_by(
            models.Journal.journal_date.desc(),
            models.Journal.id.desc(),
        )
        .all()
    )

    return [
        journal_to_out(journal)
        for journal in journals
    ]


@app.post("/api/v1/journals")
def create_journal(
    body: schemas.JournalIn,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    cid = require_company_id(
        user,
        body.company_id,
        db,
    )

    if not body.lines or len(body.lines) < 2:

        raise HTTPException(
            status_code=400,
            detail="A journal requires at least two lines",
        )

    # --------------------------------------------------------
    # Validate status
    # --------------------------------------------------------

    status = str(
        body.status or "Draft"
    ).strip()

    status_map = {
        "draft": "Draft",
        "posted": "Posted",
        "approved": "Approved",
        "pending": "Pending Approval",
        "pending approval": "Pending Approval",
    }

    status = status_map.get(
        status.lower(),
        status,
    )

    allowed_statuses = {
        "Draft",
        "Approved",
        "Pending Approval",
        "Posted",
    }

    if status not in allowed_statuses:

        raise HTTPException(
            status_code=400,
            detail=(
                "Journal status must be Draft, Approved, "
                "Pending Approval or Posted"
            ),
        )

    # --------------------------------------------------------
    # Validate journal date
    # --------------------------------------------------------

    journal_date = (
        body.journal_date
        or body.date
        or date.today()
    )

    # --------------------------------------------------------
    # Validate journal lines
    # --------------------------------------------------------

    total_debit = 0.0
    total_credit = 0.0

    validated_lines = []

    for index, line in enumerate(
        body.lines,
        start=1,
    ):

        debit = round(
            float(line.debit or 0),
            2,
        )

        credit = round(
            float(line.credit or 0),
            2,
        )

        if debit < 0:

            raise HTTPException(
                status_code=400,
                detail=(
                    f"Journal line {index}: "
                    "debit cannot be negative"
                ),
            )

        if credit < 0:

            raise HTTPException(
                status_code=400,
                detail=(
                    f"Journal line {index}: "
                    "credit cannot be negative"
                ),
            )

        if debit > 0 and credit > 0:

            raise HTTPException(
                status_code=400,
                detail=(
                    f"Journal line {index}: "
                    "a line cannot contain both debit and credit"
                ),
            )

        if debit == 0 and credit == 0:

            raise HTTPException(
                status_code=400,
                detail=(
                    f"Journal line {index}: "
                    "debit or credit amount is required"
                ),
            )

        if (
            line.account_id is None
            and not line.account_code
            and not line.account
        ):

            raise HTTPException(
                status_code=400,
                detail=(
                    f"Journal line {index}: "
                    "account is required"
                ),
            )

        total_debit += debit
        total_credit += credit

        validated_lines.append(
            (
                line,
                debit,
                credit,
            )
        )

    total_debit = round(
        total_debit,
        2,
    )

    total_credit = round(
        total_credit,
        2,
    )

    if abs(total_debit - total_credit) > 0.01:

        raise HTTPException(
            status_code=400,
            detail=(
                f"Journal is not balanced. "
                f"Debits: R{total_debit:.2f}, "
                f"Credits: R{total_credit:.2f}"
            ),
        )

    # --------------------------------------------------------
    # Clean header values
    # --------------------------------------------------------

    description = (
        body.description.strip()
        if body.description
        else None
    )

    reference = (
        body.reference.strip()
        if body.reference
        else None
    )

    # --------------------------------------------------------
    # Create journal header
    # --------------------------------------------------------

    journal = models.Journal(
        company_id=cid,
        journal_number=next_doc_number(
            db,
            cid,
            "journal",
            "JE",
        ),
        journal_date=journal_date,
        reference=reference,
        description=description,
        status=status,
        created_by=user.id,
    )

    db.add(journal)
    db.flush()

    # --------------------------------------------------------
    # Create journal lines
    # --------------------------------------------------------

    for index, (
        line,
        debit,
        credit,
    ) in enumerate(
        validated_lines,
        start=1,
    ):

        account = resolve_account(
            db,
            cid,
            line.account_id,
            line.account_code,
            line.account,
        )

        if not account:

            raise HTTPException(
                status_code=400,
                detail=(
                    f"Journal line {index}: "
                    "account not found"
                ),
            )

        if (
            hasattr(account, "is_active")
            and account.is_active is False
        ):

            raise HTTPException(
                status_code=400,
                detail=(
                    f"Journal line {index}: "
                    f"account {account.code} is inactive"
                ),
            )

        line_description = (
            line.description.strip()
            if line.description
            else None
        )

        line_order = (
            line.line_order
            if line.line_order is not None
            else index
        )

        db.add(
            models.JournalLine(
                journal_id=journal.id,
                account_id=account.id,
                account_code=account.code,
                description=line_description,
                debit=debit,
                credit=credit,
                line_order=line_order,
            )
        )

    db.flush()

    # --------------------------------------------------------
    # POST JOURNAL
    # --------------------------------------------------------

    if status == "Posted":

        if hasattr(journal, "posted_at"):
            journal.posted_at = datetime.utcnow()

        journal = (
            db.query(models.Journal)
            .options(
                joinedload(models.Journal.lines)
            )
            .filter(
                models.Journal.id == journal.id,
                models.Journal.company_id == cid,
            )
            .first()
        )

        if not journal:

            raise HTTPException(
                status_code=500,
                detail="Could not reload created journal",
            )

        apply_journal_balances(
            db,
            journal,
        )

    # --------------------------------------------------------
    # Commit
    # --------------------------------------------------------

    db.commit()

    journal = (
        db.query(models.Journal)
        .options(
            joinedload(models.Journal.lines)
        )
        .filter(
            models.Journal.id == journal.id,
            models.Journal.company_id == cid,
        )
        .first()
    )

    if not journal:

        raise HTTPException(
            status_code=500,
            detail="Journal was created but could not be loaded",
        )

    return journal_to_out(journal)


# ============================================================
# QUOTES
# ============================================================

def quote_to_out(quote):

    return {
        "id": quote.id,
        "company_id": quote.company_id,
        "customer_id": quote.customer_id,
        "quote_number": quote.quote_number,
        "quote_date": quote.quote_date,
        "valid_until": quote.valid_until,
        "subtotal": float(quote.subtotal or 0),
        "vat_amount": float(quote.vat_amount or 0),
        "total": float(quote.total or 0),
        "status": quote.status,
        "lines": [
            {
                "id": line.id,
                "description": line.description,
                "quantity": float(line.quantity or 0),
                "unit_price": float(line.unit_price or 0),
                "vat_rate": float(line.vat_rate or 0),
                "discount_percent": float(
                    line.discount_percent or 0
                ),
                "line_order": line.line_order,
            }
            for line in (quote.lines or [])
        ],
    }


@app.get("/api/v1/quotes")
def list_quotes(
    company_id: int,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    cid = require_company_id(
        user,
        company_id,
        db,
    )

    quotes = (
        db.query(models.Quote)
        .options(
            joinedload(models.Quote.lines)
        )
        .filter(
            models.Quote.company_id == cid
        )
        .order_by(
            models.Quote.id.desc()
        )
        .all()
    )

    return [
        quote_to_out(quote)
        for quote in quotes
    ]


@app.post("/api/v1/quotes")
def create_quote(
    body: schemas.QuoteIn,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    cid = require_company_id(
        user,
        body.company_id,
        db,
    )

    customer = (
        db.query(models.Customer)
        .filter(
            models.Customer.id == body.customer_id,
            models.Customer.company_id == cid,
        )
        .first()
    )

    if not customer:

        raise HTTPException(
            status_code=404,
            detail="Customer not found",
        )

    subtotal, vat, total = line_totals(
        body.lines
    )

    quote = models.Quote(
        company_id=cid,
        customer_id=customer.id,
        quote_number=next_doc_number(
            db,
            cid,
            "quote",
            "QT",
        ),
        quote_date=(
            body.quote_date
            or date.today()
        ),
        valid_until=body.valid_until,
        subtotal=subtotal,
        vat_amount=vat,
        total=total,
        status=body.status,
    )

    db.add(quote)
    db.flush()

    for line in body.lines:

        db.add(
            models.QuoteLine(
                quote_id=quote.id,
                description=line.description,
                quantity=line.quantity,
                unit_price=line.unit_price,
                vat_rate=line.vat_rate,
                discount_percent=line.discount_percent,
                line_order=line.line_order,
            )
        )

    db.commit()

    quote = (
        db.query(models.Quote)
        .options(
            joinedload(models.Quote.lines)
        )
        .filter(
            models.Quote.id == quote.id
        )
        .first()
    )

    return quote_to_out(quote)


@app.post("/api/v1/quotes/{quote_id}/accept")
def accept_quote(
    quote_id: int,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    quote = db.get(
        models.Quote,
        quote_id,
    )

    if not quote:

        raise HTTPException(
            status_code=404,
            detail="Quote not found",
        )

    cid = require_company_id(
        user,
        quote.company_id,
        db,
    )

    if quote.company_id != cid:

        raise HTTPException(
            status_code=403,
            detail="Access denied",
        )

    quote.status = "Accepted"

    db.commit()
    db.refresh(quote)

    return quote_to_out(quote)


# ============================================================
# SALES ORDERS
# ============================================================

def so_to_out(order):

    return {
        "id": order.id,
        "company_id": order.company_id,
        "customer_id": order.customer_id,
        "order_number": order.order_number,
        "order_date": order.order_date,
        "delivery_date": order.delivery_date,
        "subtotal": float(order.subtotal or 0),
        "vat_amount": float(order.vat_amount or 0),
        "total": float(order.total or 0),
        "status": order.status,
        "lines": [
            {
                "id": line.id,
                "description": line.description,
                "quantity": float(line.quantity or 0),
                "unit_price": float(line.unit_price or 0),
                "vat_rate": float(line.vat_rate or 0),
                "discount_percent": float(
                    line.discount_percent or 0
                ),
                "line_order": line.line_order,
            }
            for line in (order.lines or [])
        ],
    }


@app.get("/api/v1/sales-orders")
def list_sales_orders(
    company_id: int,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    cid = require_company_id(
        user,
        company_id,
        db,
    )

    orders = (
        db.query(models.SalesOrder)
        .options(
            joinedload(models.SalesOrder.lines)
        )
        .filter(
            models.SalesOrder.company_id == cid
        )
        .order_by(
            models.SalesOrder.id.desc()
        )
        .all()
    )

    return [
        so_to_out(order)
        for order in orders
    ]


@app.post("/api/v1/sales-orders")
def create_sales_order(
    body: schemas.SalesOrderIn,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    cid = require_company_id(
        user,
        body.company_id,
        db,
    )

    customer = (
        db.query(models.Customer)
        .filter(
            models.Customer.id == body.customer_id,
            models.Customer.company_id == cid,
        )
        .first()
    )

    if not customer:

        raise HTTPException(
            status_code=404,
            detail="Customer not found",
        )

    subtotal, vat, total = line_totals(
        body.lines
    )

    order = models.SalesOrder(
        company_id=cid,
        customer_id=customer.id,
        order_number=next_doc_number(
            db,
            cid,
            "sales_order",
            "SO",
        ),
        order_date=(
            body.order_date
            or date.today()
        ),
        delivery_date=body.delivery_date,
        subtotal=subtotal,
        vat_amount=vat,
        total=total,
        status=body.status,
    )

    db.add(order)
    db.flush()

    for line in body.lines:

        db.add(
            models.SalesOrderLine(
                sales_order_id=order.id,
                description=line.description,
                quantity=line.quantity,
                unit_price=line.unit_price,
                vat_rate=line.vat_rate,
                discount_percent=line.discount_percent,
                line_order=line.line_order,
            )
        )

    db.commit()

    order = (
        db.query(models.SalesOrder)
        .options(
            joinedload(models.SalesOrder.lines)
        )
        .filter(
            models.SalesOrder.id == order.id
        )
        .first()
    )

    return so_to_out(order)


# ============================================================
# INVOICES
# ============================================================

def invoice_to_out(invoice):

    return {
        "id": invoice.id,
        "company_id": invoice.company_id,
        "customer_id": invoice.customer_id,
        "invoice_number": invoice.invoice_number,
        "invoice_date": invoice.invoice_date,
        "due_date": invoice.due_date,
        "description": invoice.description,
        "subtotal": float(invoice.subtotal or 0),
        "vat_amount": float(invoice.vat_amount or 0),
        "total": float(invoice.total or 0),
        "amount_paid": float(invoice.amount_paid or 0),
        "paid": float(invoice.amount_paid or 0),
        "status": invoice.status,
        "lines": [
            {
                "id": line.id,
                "description": line.description,
                "quantity": float(line.quantity or 0),
                "unit_price": float(line.unit_price or 0),
                "vat_rate": float(line.vat_rate or 0),
                "discount_percent": float(
                    line.discount_percent or 0
                ),
                "line_order": line.line_order,
            }
            for line in (invoice.lines or [])
        ],
    }


@app.get("/api/v1/invoices")
def list_invoices(
    company_id: int,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    cid = require_company_id(
        user,
        company_id,
        db,
    )

    invoices = (
        db.query(models.Invoice)
        .options(
            joinedload(models.Invoice.lines)
        )
        .filter(
            models.Invoice.company_id == cid
        )
        .order_by(
            models.Invoice.invoice_date.desc(),
            models.Invoice.id.desc(),
        )
        .all()
    )

    return [
        invoice_to_out(invoice)
        for invoice in invoices
    ]


@app.post("/api/v1/invoices")
def create_invoice(
    body: schemas.InvoiceIn,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    cid = require_company_id(
        user,
        body.company_id,
        db,
    )

    customer = (
        db.query(models.Customer)
        .filter(
            models.Customer.id == body.customer_id,
            models.Customer.company_id == cid,
        )
        .first()
    )

    if not customer:

        raise HTTPException(
            status_code=404,
            detail="Customer not found",
        )

    subtotal, vat, total = line_totals(
        body.lines
    )

    invoice = models.Invoice(
        company_id=cid,
        customer_id=customer.id,
        invoice_number=next_doc_number(
            db,
            cid,
            "invoice",
            "INV",
        ),
        invoice_date=(
            body.invoice_date
            or date.today()
        ),
        due_date=body.due_date,
        description=body.description,
        subtotal=subtotal,
        vat_amount=vat,
        total=total,
        amount_paid=0,
        status=body.status,
    )

    db.add(invoice)
    db.flush()

    for line in body.lines:

        db.add(
            models.InvoiceLine(
                invoice_id=invoice.id,
                description=line.description,
                quantity=line.quantity,
                unit_price=line.unit_price,
                vat_rate=line.vat_rate,
                discount_percent=line.discount_percent,
                line_order=line.line_order,
            )
        )

    db.commit()

    invoice = (
        db.query(models.Invoice)
        .options(
            joinedload(models.Invoice.lines)
        )
        .filter(
            models.Invoice.id == invoice.id
        )
        .first()
    )

    return invoice_to_out(invoice)


@app.post("/api/v1/invoices/{invoice_id}/approve")
def approve_invoice(
    invoice_id: int,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    invoice = db.get(
        models.Invoice,
        invoice_id,
    )

    if not invoice:

        raise HTTPException(
            status_code=404,
            detail="Invoice not found",
        )

    cid = require_company_id(
        user,
        invoice.company_id,
        db,
    )

    if invoice.company_id != cid:

        raise HTTPException(
            status_code=403,
            detail="Access denied",
        )

    if invoice.status == "Posted":

        return invoice_to_out(invoice)

    invoice.status = "Approved"

    db.commit()

    invoice = (
        db.query(models.Invoice)
        .options(
            joinedload(models.Invoice.lines)
        )
        .filter(
            models.Invoice.id == invoice.id
        )
        .first()
    )

    return invoice_to_out(invoice)


@app.post("/api/v1/invoices/{invoice_id}/post")
def post_invoice(
    invoice_id: int,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    invoice = (
        db.query(models.Invoice)
        .options(
            joinedload(models.Invoice.lines)
        )
        .filter(
            models.Invoice.id == invoice_id
        )
        .first()
    )

    if not invoice:

        raise HTTPException(
            status_code=404,
            detail="Invoice not found",
        )

    cid = require_company_id(
        user,
        invoice.company_id,
        db,
    )

    if invoice.company_id != cid:

        raise HTTPException(
            status_code=403,
            detail="Access denied",
        )

    existing_journal = (
        db.query(models.Journal)
        .filter(
            models.Journal.company_id == cid,
            models.Journal.reference
            == invoice.invoice_number,
        )
        .first()
    )

    if invoice.status == "Posted" and existing_journal:

        return invoice_to_out(invoice)

    customer = (
        db.query(models.Customer)
        .filter(
            models.Customer.id == invoice.customer_id,
            models.Customer.company_id == cid,
        )
        .first()
    )

    if not customer:

        raise HTTPException(
            status_code=404,
            detail="Invoice customer not found",
        )

    ar_account = resolve_account(
        db,
        cid,
        account_code="1100",
    )

    revenue_account = resolve_account(
        db,
        cid,
        account_code="4000",
    )

    vat_account = resolve_account(
        db,
        cid,
        account_code="2100",
    )

    if not ar_account:

        raise HTTPException(
            status_code=500,
            detail="Accounts Receivable account 1100 not found",
        )

    if not revenue_account:

        raise HTTPException(
            status_code=500,
            detail="Revenue account 4000 not found",
        )

    if not vat_account:

        raise HTTPException(
            status_code=500,
            detail="VAT Output account 2100 not found",
        )

    # --------------------------------------------------------
    # REPAIR MODE
    # --------------------------------------------------------

    if invoice.status == "Posted" and not existing_journal:

        journal = models.Journal(
            company_id=cid,
            journal_number=next_doc_number(
                db,
                cid,
                "journal",
                "JE",
            ),
            journal_date=invoice.invoice_date,
            reference=invoice.invoice_number,
            description=(
                f"Invoice posting - "
                f"{invoice.invoice_number}"
            ),
            status="Posted",
        )

        db.add(journal)
        db.flush()

        db.add(
            models.JournalLine(
                journal_id=journal.id,
                account_id=ar_account.id,
                account_code=ar_account.code,
                description=(
                    f"Accounts receivable - "
                    f"{invoice.invoice_number}"
                ),
                debit=float(invoice.total or 0),
                credit=0,
                line_order=1,
            )
        )

        db.add(
            models.JournalLine(
                journal_id=journal.id,
                account_id=revenue_account.id,
                account_code=revenue_account.code,
                description=(
                    f"Revenue - "
                    f"{invoice.invoice_number}"
                ),
                debit=0,
                credit=float(invoice.subtotal or 0),
                line_order=2,
            )
        )

        db.add(
            models.JournalLine(
                journal_id=journal.id,
                account_id=vat_account.id,
                account_code=vat_account.code,
                description=(
                    f"VAT output - "
                    f"{invoice.invoice_number}"
                ),
                debit=0,
                credit=float(invoice.vat_amount or 0),
                line_order=3,
            )
        )

        db.flush()

        journal = (
            db.query(models.Journal)
            .options(
                joinedload(models.Journal.lines)
            )
            .filter(
                models.Journal.id == journal.id
            )
            .first()
        )

        apply_journal_balances(
            db,
            journal,
        )

        db.commit()

        return invoice_to_out(invoice)

    # --------------------------------------------------------
    # NORMAL FIRST POSTING
    # --------------------------------------------------------

    invoice.status = "Posted"

    if hasattr(invoice, "posted_at"):
        invoice.posted_at = datetime.utcnow()

    customer.balance = (
        float(customer.balance or 0)
        + float(invoice.total or 0)
    )

    journal = models.Journal(
        company_id=cid,
        journal_number=next_doc_number(
            db,
            cid,
            "journal",
            "JE",
        ),
        journal_date=invoice.invoice_date,
        reference=invoice.invoice_number,
        description=(
            f"Invoice posting - "
            f"{invoice.invoice_number}"
        ),
        status="Posted",
    )

    db.add(journal)
    db.flush()

    db.add(
        models.JournalLine(
            journal_id=journal.id,
            account_id=ar_account.id,
            account_code=ar_account.code,
            description=(
                f"Accounts receivable - "
                f"{invoice.invoice_number}"
            ),
            debit=float(invoice.total or 0),
            credit=0,
            line_order=1,
        )
    )

    db.add(
        models.JournalLine(
            journal_id=journal.id,
            account_id=revenue_account.id,
            account_code=revenue_account.code,
            description=(
                f"Revenue - "
                f"{invoice.invoice_number}"
            ),
            debit=0,
            credit=float(invoice.subtotal or 0),
            line_order=2,
        )
    )

    db.add(
        models.JournalLine(
            journal_id=journal.id,
            account_id=vat_account.id,
            account_code=vat_account.code,
            description=(
                f"VAT output - "
                f"{invoice.invoice_number}"
            ),
            debit=0,
            credit=float(invoice.vat_amount or 0),
            line_order=3,
        )
    )

    db.flush()

    journal = (
        db.query(models.Journal)
        .options(
            joinedload(models.Journal.lines)
        )
        .filter(
            models.Journal.id == journal.id
        )
        .first()
    )

    apply_journal_balances(
        db,
        journal,
    )

    db.commit()

    invoice = (
        db.query(models.Invoice)
        .options(
            joinedload(models.Invoice.lines)
        )
        .filter(
            models.Invoice.id == invoice.id
        )
        .first()
    )

    return invoice_to_out(invoice)


# ============================================================
# RECEIPTS
# ============================================================

def receipt_to_out(receipt):

    return {
        "id": receipt.id,
        "company_id": receipt.company_id,
        "customer_id": receipt.customer_id,
        "receipt_number": receipt.receipt_number,
        "receipt_date": (
            receipt.receipt_date.isoformat()
            if receipt.receipt_date
            else None
        ),
        "reference": receipt.reference,
        "description": receipt.description,
        "amount": float(receipt.amount or 0),
        "bank_account_id": receipt.bank_account_id,
        "status": receipt.status,
        "allocations": [
            {
                "id": allocation.id,
                "invoice_id": allocation.invoice_id,
                "amount": float(
                    allocation.amount or 0
                ),
            }
            for allocation in (
                receipt.allocations or []
            )
        ],
    }


def validate_receipt_allocations(
    db: Session,
    receipt_company_id: int,
    customer_id: int,
    receipt_amount: float,
    allocations,
):
    """
    Validate all receipt allocations.

    Returns the loaded invoices and their allocation amounts.
    """

    if not allocations:

        raise HTTPException(
            status_code=400,
            detail=(
                "A receipt must be allocated "
                "to at least one invoice"
            ),
        )

    total_allocated = 0.0
    loaded = []

    for allocation in allocations:

        allocation_amount = round(
            float(allocation.amount or 0),
            2,
        )

        if allocation_amount <= 0:

            raise HTTPException(
                status_code=400,
                detail=(
                    "Receipt allocation amount "
                    "must be greater than zero"
                ),
            )

        invoice = (
            db.query(models.Invoice)
            .filter(
                models.Invoice.id == allocation.invoice_id,
                models.Invoice.company_id == receipt_company_id,
                models.Invoice.customer_id == customer_id,
            )
            .first()
        )

        if not invoice:

            raise HTTPException(
                status_code=404,
                detail=(
                    f"Invoice {allocation.invoice_id} "
                    "was not found for this customer"
                ),
            )

        outstanding = round(
            float(invoice.total or 0)
            - float(invoice.amount_paid or 0),
            2,
        )

        if outstanding <= 0:

            raise HTTPException(
                status_code=400,
                detail=(
                    f"Invoice {invoice.invoice_number} "
                    "is already fully paid"
                ),
            )

        if allocation_amount > outstanding + 0.01:

            raise HTTPException(
                status_code=400,
                detail=(
                    f"Allocation of R{allocation_amount:.2f} exceeds "
                    f"the outstanding balance of "
                    f"R{outstanding:.2f} on "
                    f"{invoice.invoice_number}"
                ),
            )

        if invoice.status not in (
            "Posted",
            "Partially Paid",
            "Paid",
        ):

            raise HTTPException(
                status_code=400,
                detail=(
                    f"Invoice {invoice.invoice_number} "
                    "must be Posted before receiving payment"
                ),
            )

        total_allocated += allocation_amount

        loaded.append(
            (
                invoice,
                allocation_amount,
            )
        )

    total_allocated = round(
        total_allocated,
        2,
    )

    receipt_amount = round(
        float(receipt_amount or 0),
        2,
    )

    if abs(total_allocated - receipt_amount) > 0.01:

        raise HTTPException(
            status_code=400,
            detail=(
                f"Receipt amount R{receipt_amount:.2f} "
                f"does not equal allocated amount "
                f"R{total_allocated:.2f}"
            ),
        )

    return loaded


@app.get("/api/v1/receipts")
def list_receipts(
    company_id: int,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    cid = require_company_id(
        user,
        company_id,
        db,
    )

    receipts = (
        db.query(models.Receipt)
        .options(
            joinedload(models.Receipt.allocations)
        )
        .filter(
            models.Receipt.company_id == cid
        )
        .order_by(
            models.Receipt.receipt_date.desc(),
            models.Receipt.id.desc(),
        )
        .all()
    )

    return [
        receipt_to_out(receipt)
        for receipt in receipts
    ]


@app.post("/api/v1/receipts")
def create_receipt(
    body: schemas.ReceiptIn,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    cid = require_company_id(
        user,
        body.company_id,
        db,
    )

    amount = round(
        float(body.amount or 0),
        2,
    )

    if amount <= 0:

        raise HTTPException(
            status_code=400,
            detail="Receipt amount must be greater than zero",
        )

    customer = (
        db.query(models.Customer)
        .filter(
            models.Customer.id == body.customer_id,
            models.Customer.company_id == cid,
        )
        .first()
    )

    if not customer:

        raise HTTPException(
            status_code=404,
            detail="Customer not found",
        )

    # --------------------------------------------------------
    # Bank account
    # --------------------------------------------------------

    if body.bank_account_id is not None:

        bank_account = (
            db.query(models.Account)
            .filter(
                models.Account.id == body.bank_account_id,
                models.Account.company_id == cid,
            )
            .first()
        )

        if not bank_account:

            raise HTTPException(
                status_code=404,
                detail="Bank account not found",
            )

    else:

        bank_account = resolve_account(
            db,
            cid,
            account_code="1000",
        )

        if not bank_account:

            raise HTTPException(
                status_code=500,
                detail=(
                    "Default bank account 1000 "
                    "was not found"
                ),
            )

    if bank_account.account_type != "Assets":

        raise HTTPException(
            status_code=400,
            detail=(
                "Receipt bank account "
                "must be an Asset account"
            ),
        )

    # --------------------------------------------------------
    # Validate status
    # --------------------------------------------------------

    allowed_statuses = {
        "Draft",
        "Approved",
        "Posted",
    }

    if body.status not in allowed_statuses:

        raise HTTPException(
            status_code=400,
            detail=(
                "Receipt status must be "
                "Draft, Approved or Posted"
            ),
        )

    # --------------------------------------------------------
    # Validate allocations
    # --------------------------------------------------------

    validate_receipt_allocations(
        db,
        cid,
        customer.id,
        amount,
        body.allocations,
    )

    # --------------------------------------------------------
    # Create receipt
    # --------------------------------------------------------

    receipt = models.Receipt(
        company_id=cid,
        customer_id=customer.id,
        receipt_number=next_doc_number(
            db,
            cid,
            "receipt",
            "RCPT",
        ),
        receipt_date=(
            body.receipt_date
            or date.today()
        ),
        reference=body.reference,
        description=body.description,
        amount=amount,
        bank_account_id=bank_account.id,
        status=(
            "Draft"
            if body.status == "Posted"
            else body.status
        ),
        created_by=user.id,
    )

    db.add(receipt)
    db.flush()

    for allocation in body.allocations:

        db.add(
            models.ReceiptAllocation(
                receipt_id=receipt.id,
                invoice_id=allocation.invoice_id,
                amount=round(
                    float(allocation.amount),
                    2,
                ),
            )
        )

    db.commit()

    # --------------------------------------------------------
    # Immediate posting
    # --------------------------------------------------------

    if body.status == "Posted":

        return post_receipt(
            receipt.id,
            user,
            db,
        )

    receipt = (
        db.query(models.Receipt)
        .options(
            joinedload(models.Receipt.allocations)
        )
        .filter(
            models.Receipt.id == receipt.id
        )
        .first()
    )

    return receipt_to_out(receipt)


@app.post("/api/v1/receipts/{receipt_id}/post")
def post_receipt(
    receipt_id: int,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    receipt = (
        db.query(models.Receipt)
        .options(
            joinedload(models.Receipt.allocations)
        )
        .filter(
            models.Receipt.id == receipt_id
        )
        .first()
    )

    if not receipt:

        raise HTTPException(
            status_code=404,
            detail="Receipt not found",
        )

    cid = require_company_id(
        user,
        receipt.company_id,
        db,
    )

    if receipt.company_id != cid:

        raise HTTPException(
            status_code=403,
            detail="Access denied",
        )

    # --------------------------------------------------------
    # Customer
    # --------------------------------------------------------

    customer = (
        db.query(models.Customer)
        .filter(
            models.Customer.id == receipt.customer_id,
            models.Customer.company_id == cid,
        )
        .first()
    )

    if not customer:

        raise HTTPException(
            status_code=404,
            detail="Receipt customer not found",
        )

    # --------------------------------------------------------
    # Bank account
    # --------------------------------------------------------

    bank_account = (
        db.query(models.Account)
        .filter(
            models.Account.id == receipt.bank_account_id,
            models.Account.company_id == cid,
        )
        .first()
    )

    if not bank_account:

        raise HTTPException(
            status_code=500,
            detail="Receipt bank account not found",
        )

    if bank_account.account_type != "Assets":

        raise HTTPException(
            status_code=400,
            detail=(
                "Receipt bank account "
                "must be an Asset account"
            ),
        )

    # --------------------------------------------------------
    # Find existing receipt journal
    # --------------------------------------------------------

    existing_journal = (
        db.query(models.Journal)
        .filter(
            models.Journal.company_id == cid,
            models.Journal.reference
            == receipt.receipt_number,
        )
        .first()
    )

    # --------------------------------------------------------
    # Already posted
    # --------------------------------------------------------

    if (
        receipt.status in ("Posted", "Paid")
        and existing_journal
    ):

        receipt = (
            db.query(models.Receipt)
            .options(
                joinedload(models.Receipt.allocations)
            )
            .filter(
                models.Receipt.id == receipt.id
            )
            .first()
        )

        return receipt_to_out(receipt)

    # --------------------------------------------------------
    # Validate allocations
    # --------------------------------------------------------

    allocation_pairs = []

    for allocation in (
        receipt.allocations or []
    ):

        amount = round(
            float(allocation.amount or 0),
            2,
        )

        if amount <= 0:

            raise HTTPException(
                status_code=400,
                detail=(
                    "Receipt allocation amount "
                    "must be greater than zero"
                ),
            )

        invoice = (
            db.query(models.Invoice)
            .filter(
                models.Invoice.id == allocation.invoice_id,
                models.Invoice.company_id == cid,
                models.Invoice.customer_id == receipt.customer_id,
            )
            .first()
        )

        if not invoice:

            raise HTTPException(
                status_code=404,
                detail=(
                    f"Invoice {allocation.invoice_id} "
                    "was not found for this receipt customer"
                ),
            )

        outstanding = round(
            float(invoice.total or 0)
            - float(invoice.amount_paid or 0),
            2,
        )

        if receipt.status not in (
            "Posted",
            "Paid",
        ):

            if outstanding <= 0:

                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"Invoice {invoice.invoice_number} "
                        "is already fully paid"
                    ),
                )

            if amount > outstanding + 0.01:

                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"Allocation of R{amount:.2f} exceeds "
                        f"outstanding balance R{outstanding:.2f} "
                        f"on {invoice.invoice_number}"
                    ),
                )

            if invoice.status not in (
                "Posted",
                "Partially Paid",
                "Paid",
            ):

                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"Invoice {invoice.invoice_number} "
                        "must be Posted before payment"
                    ),
                )

        allocation_pairs.append(
            (
                invoice,
                amount,
            )
        )

    if not allocation_pairs:

        raise HTTPException(
            status_code=400,
            detail="Receipt has no allocations",
        )

    total_allocated = round(
        sum(
            amount
            for _, amount in allocation_pairs
        ),
        2,
    )

    receipt_amount = round(
        float(receipt.amount or 0),
        2,
    )

    if abs(total_allocated - receipt_amount) > 0.01:

        raise HTTPException(
            status_code=400,
            detail=(
                f"Receipt amount R{receipt_amount:.2f} "
                f"does not equal allocations "
                f"R{total_allocated:.2f}"
            ),
        )

    # --------------------------------------------------------
    # Accounts Receivable
    # --------------------------------------------------------

    ar_account = resolve_account(
        db,
        cid,
        account_code="1100",
    )

    if not ar_account:

        raise HTTPException(
            status_code=500,
            detail=(
                "Accounts Receivable account "
                "1100 was not found"
            ),
        )

    # --------------------------------------------------------
    # REPAIR MODE
    # --------------------------------------------------------

    if (
        receipt.status in ("Posted", "Paid")
        and not existing_journal
    ):

        journal = models.Journal(
            company_id=cid,
            journal_number=next_doc_number(
                db,
                cid,
                "journal",
                "JE",
            ),
            journal_date=receipt.receipt_date,
            reference=receipt.receipt_number,
            description=(
                f"Customer receipt - "
                f"{receipt.receipt_number}"
            ),
            status="Posted",
        )

        db.add(journal)
        db.flush()

        db.add(
            models.JournalLine(
                journal_id=journal.id,
                account_id=bank_account.id,
                account_code=bank_account.code,
                description=(
                    f"Bank receipt - "
                    f"{receipt.receipt_number}"
                ),
                debit=receipt_amount,
                credit=0,
                line_order=1,
            )
        )

        db.add(
            models.JournalLine(
                journal_id=journal.id,
                account_id=ar_account.id,
                account_code=ar_account.code,
                description=(
                    f"Accounts receivable payment - "
                    f"{receipt.receipt_number}"
                ),
                debit=0,
                credit=receipt_amount,
                line_order=2,
            )
        )

        db.flush()

        journal = (
            db.query(models.Journal)
            .options(
                joinedload(models.Journal.lines)
            )
            .filter(
                models.Journal.id == journal.id
            )
            .first()
        )

        apply_journal_balances(
            db,
            journal,
        )

        db.commit()

        receipt = (
            db.query(models.Receipt)
            .options(
                joinedload(models.Receipt.allocations)
            )
            .filter(
                models.Receipt.id == receipt.id
            )
            .first()
        )

        return receipt_to_out(receipt)

    # --------------------------------------------------------
    # NORMAL FIRST POST
    # --------------------------------------------------------

    receipt.status = "Posted"

    if hasattr(receipt, "posted_at"):
        receipt.posted_at = datetime.utcnow()

    customer.balance = round(
        float(customer.balance or 0)
        - receipt_amount,
        2,
    )

    for invoice, allocation_amount in allocation_pairs:

        invoice.amount_paid = round(
            float(invoice.amount_paid or 0)
            + allocation_amount,
            2,
        )

        if (
            float(invoice.amount_paid or 0)
            >= float(invoice.total or 0) - 0.01
        ):

            invoice.amount_paid = round(
                float(invoice.total or 0),
                2,
            )

            invoice.status = "Paid"

        else:

            invoice.status = "Partially Paid"

    # --------------------------------------------------------
    # Create GL journal
    #
    # DR 1000 Bank
    # CR 1100 Accounts Receivable
    # --------------------------------------------------------

    journal = models.Journal(
        company_id=cid,
        journal_number=next_doc_number(
            db,
            cid,
            "journal",
            "JE",
        ),
        journal_date=receipt.receipt_date,
        reference=receipt.receipt_number,
        description=(
            f"Customer receipt - "
            f"{receipt.receipt_number}"
        ),
        status="Posted",
    )

    db.add(journal)
    db.flush()

    db.add(
        models.JournalLine(
            journal_id=journal.id,
            account_id=bank_account.id,
            account_code=bank_account.code,
            description=(
                f"Bank receipt - "
                f"{receipt.receipt_number}"
            ),
            debit=receipt_amount,
            credit=0,
            line_order=1,
        )
    )

    db.add(
        models.JournalLine(
            journal_id=journal.id,
            account_id=ar_account.id,
            account_code=ar_account.code,
            description=(
                f"Accounts receivable payment - "
                f"{receipt.receipt_number}"
            ),
            debit=0,
            credit=receipt_amount,
            line_order=2,
        )
    )

    db.flush()

    journal = (
        db.query(models.Journal)
        .options(
            joinedload(models.Journal.lines)
        )
        .filter(
            models.Journal.id == journal.id
        )
        .first()
    )

    apply_journal_balances(
        db,
        journal,
    )

    db.commit()

    receipt = (
        db.query(models.Receipt)
        .options(
            joinedload(models.Receipt.allocations)
        )
        .filter(
            models.Receipt.id == receipt.id
        )
        .first()
    )

    return receipt_to_out(receipt)