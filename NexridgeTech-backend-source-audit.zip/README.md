# NexridgeTech ERP — Backend + Database

Full multi-tenant accounting database and FastAPI API that matches the `erp.html` frontend.

## What is included

### Database tables
- **Platform:** companies, users, company_users, document_sequences, audit_log
- **GL:** accounts, journals, journal_lines
- **Sales:** customers, quotes, quote_lines, sales_orders, sales_order_lines, invoices, invoice_lines
- **Purchases:** suppliers, purchase_orders, bills
- **Banking:** bank_accounts, bank_transactions
- **Inventory / Payroll stubs:** products, employees

### API endpoints (used by the frontend)
| Method | Path | Purpose |
|--------|------|---------|
| POST | `/api/v1/auth/login` | Login → JWT + company_id |
| GET | `/api/v1/auth/me` | Current user |
| GET | `/api/v1/companies` | Companies for user |
| GET/POST | `/api/v1/customers` | List / create customers |
| GET/POST | `/api/v1/accounts` | Chart of accounts |
| PATCH | `/api/v1/accounts/{id}` | Update account |
| GET/POST | `/api/v1/journals` | Journal entries |
| GET/POST | `/api/v1/quotes` | Quotes |
| POST | `/api/v1/quotes/{id}/accept` | Accept quote |
| GET/POST | `/api/v1/sales-orders` | Sales orders |
| GET/POST | `/api/v1/invoices` | Invoices |
| POST | `/api/v1/invoices/{id}/approve` | Approve invoice |
| POST | `/api/v1/invoices/{id}/post` | Post invoice |

## Quick start (SQLite — easiest)

```bash
cd nexridge-backend
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# Default DATABASE_URL is sqlite:///./nexridge_erp.db
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

Open API docs: http://127.0.0.1:8000/docs

### Default login (seeded on first start)
- **Email:** `admin@nexridgetech.co.za`
- **Password:** `admin123`
- **Company:** NexridgeTech IT Solutions (`company_id = 1`)

## PostgreSQL (production-style)

1. Create database and user:
```sql
CREATE USER nexridge WITH PASSWORD 'nexridge';
CREATE DATABASE nexridge_erp OWNER nexridge;
```

2. Optional: apply raw SQL schema:
```bash
psql -U nexridge -d nexridge_erp -f sql/schema.sql
```

3. Set env and run:
```bash
export DATABASE_URL=postgresql+psycopg2://nexridge:nexridge@localhost:5432/nexridge_erp
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

(Tables are also auto-created by SQLAlchemy on startup if missing.)

## Connect the frontend

1. Keep `erp.html` and `erp-login.html` on the same origin or open via a local static server.
2. Frontend already uses:
   ```js
   const API_BASE = 'http://127.0.0.1:8000/api/v1';
   ```
3. Start the API on port **8000**.
4. Open `erp-login.html` → sign in with the seeded admin user.
5. Customers, COA, Journals, Quotes, Sales Orders, Invoices will load and create against this database.

## Chart of accounts seed
On first run the system creates standard SA SME accounts including:
1000 Bank, 1100 AR, 2000 AP, 2100 VAT Output, 3000 Share Capital, 4000 Revenue, 6100 Repairs, etc.

## Notes
- All operational rows are scoped by `company_id` (multi-tenant).
- Document numbers are generated as `PREFIX-YYYYMMDD-0001` via `document_sequences`.
- Posting a journal updates account balances.
- Posting an invoice increases customer balance.
