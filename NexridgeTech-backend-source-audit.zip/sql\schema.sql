-- NexridgeTech ERP — Full database schema (PostgreSQL)
-- Multi-tenant by company_id on all operational tables.

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ---------------------------------------------------------------------------
-- Platform / tenancy
-- ---------------------------------------------------------------------------
CREATE TABLE companies (
    id              SERIAL PRIMARY KEY,
    name            VARCHAR(255) NOT NULL,
    trading_name    VARCHAR(255),
    registration_number VARCHAR(64),
    vat_number      VARCHAR(32),
    currency        VARCHAR(8) NOT NULL DEFAULT 'ZAR',
    country         VARCHAR(64) NOT NULL DEFAULT 'South Africa',
    fiscal_year_end VARCHAR(16) DEFAULT 'February',
    address         TEXT,
    phone           VARCHAR(64),
    email           VARCHAR(255),
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE users (
    id              SERIAL PRIMARY KEY,
    email           VARCHAR(255) NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    full_name       VARCHAR(255) NOT NULL,
    role            VARCHAR(64) NOT NULL DEFAULT 'admin',
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    last_login      TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE company_users (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role            VARCHAR(64) NOT NULL DEFAULT 'admin',
    UNIQUE (company_id, user_id)
);

-- ---------------------------------------------------------------------------
-- Chart of accounts / GL
-- ---------------------------------------------------------------------------
CREATE TABLE accounts (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    code            VARCHAR(32) NOT NULL,
    name            VARCHAR(255) NOT NULL,
    account_type    VARCHAR(64) NOT NULL,  -- Assets, Liabilities, Equity, Revenue, Cost of Sales, Expenses
    sub_type        VARCHAR(128),
    tax_code        VARCHAR(64) DEFAULT 'No VAT',
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    cost_centre_required BOOLEAN NOT NULL DEFAULT FALSE,
    project_required BOOLEAN NOT NULL DEFAULT FALSE,
    balance         NUMERIC(18,2) NOT NULL DEFAULT 0,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (company_id, code)
);

CREATE TABLE journals (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    journal_number  VARCHAR(64) NOT NULL,
    journal_date    DATE NOT NULL,
    reference       VARCHAR(128),
    description     TEXT,
    status          VARCHAR(32) NOT NULL DEFAULT 'Draft', -- Draft, Pending Approval, Posted, Reversed
    created_by      INTEGER REFERENCES users(id),
    posted_at       TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (company_id, journal_number)
);

CREATE TABLE journal_lines (
    id              SERIAL PRIMARY KEY,
    journal_id      INTEGER NOT NULL REFERENCES journals(id) ON DELETE CASCADE,
    account_id      INTEGER REFERENCES accounts(id),
    account_code    VARCHAR(32),
    description     TEXT,
    debit           NUMERIC(18,2) NOT NULL DEFAULT 0,
    credit          NUMERIC(18,2) NOT NULL DEFAULT 0,
    line_order      INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX idx_journal_lines_journal ON journal_lines(journal_id);
CREATE INDEX idx_accounts_company ON accounts(company_id);

-- ---------------------------------------------------------------------------
-- Customers / Suppliers
-- ---------------------------------------------------------------------------
CREATE TABLE customers (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    code            VARCHAR(32),
    name            VARCHAR(255) NOT NULL,
    registration_number VARCHAR(64),
    vat_number      VARCHAR(32),
    contact_name    VARCHAR(255),
    email           VARCHAR(255),
    phone           VARCHAR(64),
    payment_terms   VARCHAR(64) DEFAULT '30 Days',
    credit_limit    NUMERIC(18,2) NOT NULL DEFAULT 0,
    balance         NUMERIC(18,2) NOT NULL DEFAULT 0,
    overdue         NUMERIC(18,2) NOT NULL DEFAULT 0,
    address         TEXT,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE suppliers (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    code            VARCHAR(32),
    name            VARCHAR(255) NOT NULL,
    registration_number VARCHAR(64),
    vat_number      VARCHAR(32),
    contact_name    VARCHAR(255),
    email           VARCHAR(255),
    phone           VARCHAR(64),
    payment_terms   VARCHAR(64) DEFAULT '30 Days',
    balance         NUMERIC(18,2) NOT NULL DEFAULT 0,
    overdue         NUMERIC(18,2) NOT NULL DEFAULT 0,
    address         TEXT,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_customers_company ON customers(company_id);
CREATE INDEX idx_suppliers_company ON suppliers(company_id);

-- ---------------------------------------------------------------------------
-- Sales: quotes, orders, invoices
-- ---------------------------------------------------------------------------
CREATE TABLE quotes (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    customer_id     INTEGER NOT NULL REFERENCES customers(id),
    quote_number    VARCHAR(64) NOT NULL,
    quote_date      DATE NOT NULL,
    valid_until     DATE,
    subtotal        NUMERIC(18,2) NOT NULL DEFAULT 0,
    vat_amount      NUMERIC(18,2) NOT NULL DEFAULT 0,
    total           NUMERIC(18,2) NOT NULL DEFAULT 0,
    status          VARCHAR(32) NOT NULL DEFAULT 'Draft',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (company_id, quote_number)
);

CREATE TABLE quote_lines (
    id              SERIAL PRIMARY KEY,
    quote_id        INTEGER NOT NULL REFERENCES quotes(id) ON DELETE CASCADE,
    description     TEXT NOT NULL,
    quantity        NUMERIC(18,4) NOT NULL DEFAULT 1,
    unit_price      NUMERIC(18,2) NOT NULL DEFAULT 0,
    vat_rate        NUMERIC(8,2) NOT NULL DEFAULT 15,
    discount_percent NUMERIC(8,2) NOT NULL DEFAULT 0,
    line_order      INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE sales_orders (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    customer_id     INTEGER NOT NULL REFERENCES customers(id),
    order_number    VARCHAR(64) NOT NULL,
    order_date      DATE NOT NULL,
    delivery_date   DATE,
    subtotal        NUMERIC(18,2) NOT NULL DEFAULT 0,
    vat_amount      NUMERIC(18,2) NOT NULL DEFAULT 0,
    total           NUMERIC(18,2) NOT NULL DEFAULT 0,
    status          VARCHAR(32) NOT NULL DEFAULT 'Draft',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (company_id, order_number)
);

CREATE TABLE sales_order_lines (
    id              SERIAL PRIMARY KEY,
    sales_order_id  INTEGER NOT NULL REFERENCES sales_orders(id) ON DELETE CASCADE,
    description     TEXT NOT NULL,
    quantity        NUMERIC(18,4) NOT NULL DEFAULT 1,
    unit_price      NUMERIC(18,2) NOT NULL DEFAULT 0,
    vat_rate        NUMERIC(8,2) NOT NULL DEFAULT 15,
    discount_percent NUMERIC(8,2) NOT NULL DEFAULT 0,
    line_order      INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE invoices (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    customer_id     INTEGER NOT NULL REFERENCES customers(id),
    invoice_number  VARCHAR(64) NOT NULL,
    invoice_date    DATE NOT NULL,
    due_date        DATE,
    description     TEXT,
    subtotal        NUMERIC(18,2) NOT NULL DEFAULT 0,
    vat_amount      NUMERIC(18,2) NOT NULL DEFAULT 0,
    total           NUMERIC(18,2) NOT NULL DEFAULT 0,
    amount_paid     NUMERIC(18,2) NOT NULL DEFAULT 0,
    status          VARCHAR(32) NOT NULL DEFAULT 'Draft',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    posted_at       TIMESTAMPTZ,
    UNIQUE (company_id, invoice_number)
);

CREATE TABLE invoice_lines (
    id              SERIAL PRIMARY KEY,
    invoice_id      INTEGER NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
    description     TEXT NOT NULL,
    quantity        NUMERIC(18,4) NOT NULL DEFAULT 1,
    unit_price      NUMERIC(18,2) NOT NULL DEFAULT 0,
    vat_rate        NUMERIC(8,2) NOT NULL DEFAULT 15,
    discount_percent NUMERIC(8,2) NOT NULL DEFAULT 0,
    line_order      INTEGER NOT NULL DEFAULT 0
);

-- ---------------------------------------------------------------------------
-- Purchases
-- ---------------------------------------------------------------------------
CREATE TABLE purchase_orders (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    supplier_id     INTEGER NOT NULL REFERENCES suppliers(id),
    po_number       VARCHAR(64) NOT NULL,
    order_date      DATE NOT NULL,
    expected_date   DATE,
    subtotal        NUMERIC(18,2) NOT NULL DEFAULT 0,
    vat_amount      NUMERIC(18,2) NOT NULL DEFAULT 0,
    total           NUMERIC(18,2) NOT NULL DEFAULT 0,
    status          VARCHAR(32) NOT NULL DEFAULT 'Draft',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (company_id, po_number)
);

CREATE TABLE bills (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    supplier_id     INTEGER NOT NULL REFERENCES suppliers(id),
    bill_number     VARCHAR(64) NOT NULL,
    bill_date       DATE NOT NULL,
    due_date        DATE,
    description     TEXT,
    subtotal        NUMERIC(18,2) NOT NULL DEFAULT 0,
    vat_amount      NUMERIC(18,2) NOT NULL DEFAULT 0,
    total           NUMERIC(18,2) NOT NULL DEFAULT 0,
    amount_paid     NUMERIC(18,2) NOT NULL DEFAULT 0,
    status          VARCHAR(32) NOT NULL DEFAULT 'Draft',
    gl_account_code VARCHAR(32),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (company_id, bill_number)
);

-- ---------------------------------------------------------------------------
-- Banking
-- ---------------------------------------------------------------------------
CREATE TABLE bank_accounts (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    bank_name       VARCHAR(128) NOT NULL,
    account_name    VARCHAR(255) NOT NULL,
    account_number  VARCHAR(64),
    currency        VARCHAR(8) NOT NULL DEFAULT 'ZAR',
    gl_account_id   INTEGER REFERENCES accounts(id),
    book_balance    NUMERIC(18,2) NOT NULL DEFAULT 0,
    reconciled_balance NUMERIC(18,2) NOT NULL DEFAULT 0,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE bank_transactions (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    bank_account_id INTEGER NOT NULL REFERENCES bank_accounts(id) ON DELETE CASCADE,
    txn_date        DATE NOT NULL,
    description     TEXT,
    reference       VARCHAR(128),
    debit           NUMERIC(18,2) NOT NULL DEFAULT 0,
    credit          NUMERIC(18,2) NOT NULL DEFAULT 0,
    status          VARCHAR(32) NOT NULL DEFAULT 'Unmatched',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ---------------------------------------------------------------------------
-- Inventory (core)
-- ---------------------------------------------------------------------------
CREATE TABLE products (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    sku             VARCHAR(64),
    name            VARCHAR(255) NOT NULL,
    description     TEXT,
    unit            VARCHAR(32) DEFAULT 'Each',
    sale_price      NUMERIC(18,2) NOT NULL DEFAULT 0,
    cost_price      NUMERIC(18,2) NOT NULL DEFAULT 0,
    vat_rate        NUMERIC(8,2) NOT NULL DEFAULT 15,
    qty_on_hand     NUMERIC(18,4) NOT NULL DEFAULT 0,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ---------------------------------------------------------------------------
-- Payroll (core stubs)
-- ---------------------------------------------------------------------------
CREATE TABLE employees (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    employee_number VARCHAR(32),
    first_name      VARCHAR(128) NOT NULL,
    last_name       VARCHAR(128) NOT NULL,
    email           VARCHAR(255),
    id_number       VARCHAR(32),
    job_title       VARCHAR(128),
    department      VARCHAR(128),
    start_date      DATE,
    basic_salary    NUMERIC(18,2) NOT NULL DEFAULT 0,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ---------------------------------------------------------------------------
-- Document number sequences
-- ---------------------------------------------------------------------------
CREATE TABLE document_sequences (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    doc_type        VARCHAR(64) NOT NULL, -- quote, invoice, journal, sales_order, bill, po
    prefix          VARCHAR(32) NOT NULL,
    next_number     INTEGER NOT NULL DEFAULT 1,
    UNIQUE (company_id, doc_type)
);

-- ---------------------------------------------------------------------------
-- Audit log
-- ---------------------------------------------------------------------------
CREATE TABLE audit_log (
    id              SERIAL PRIMARY KEY,
    company_id      INTEGER REFERENCES companies(id),
    user_id         INTEGER REFERENCES users(id),
    action          VARCHAR(128) NOT NULL,
    entity_type     VARCHAR(64),
    entity_id       INTEGER,
    detail          TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_audit_company ON audit_log(company_id);
