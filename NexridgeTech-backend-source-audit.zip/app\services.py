from datetime import date
from sqlalchemy.orm import Session
from fastapi import HTTPException
from app import models


def next_doc_number(db: Session, company_id: int, doc_type: str, prefix: str) -> str:
    seq = (
        db.query(models.DocumentSequence)
        .filter_by(company_id=company_id, doc_type=doc_type)
        .with_for_update()
        .first()
    )
    if not seq:
        seq = models.DocumentSequence(
            company_id=company_id, doc_type=doc_type, prefix=prefix, next_number=1
        )
        db.add(seq)
        db.flush()
    num = seq.next_number
    seq.next_number = num + 1
    today = date.today().strftime("%Y%m%d")
    return f"{prefix}-{today}-{num:04d}"


def line_totals(lines) -> tuple[float, float, float]:
    subtotal = 0.0
    vat = 0.0
    for ln in lines:
        qty = float(getattr(ln, "quantity", 1) or 1)
        price = float(getattr(ln, "unit_price", 0) or 0)
        disc = float(getattr(ln, "discount_percent", 0) or 0)
        rate = float(getattr(ln, "vat_rate", 15) or 15)
        base = qty * price * (1 - disc / 100)
        subtotal += base
        vat += base * (rate / 100)
    return round(subtotal, 2), round(vat, 2), round(subtotal + vat, 2)


def resolve_account(db: Session, company_id: int, account_id=None, account_code=None, account=None):
    code = account_code or account
    if account_id:
        acc = db.get(models.Account, account_id)
        if acc and acc.company_id == company_id:
            return acc
    if code:
        acc = (
            db.query(models.Account)
            .filter_by(company_id=company_id, code=str(code))
            .first()
        )
        if acc:
            return acc
    return None


def apply_journal_balances(db: Session, journal: models.Journal, reverse: bool = False):
    """Update account balances when posting (or reversing) a journal."""
    sign = -1 if reverse else 1
    for line in journal.lines:
        acc = None
        if line.account_id:
            acc = db.get(models.Account, line.account_id)
        elif line.account_code:
            acc = (
                db.query(models.Account)
                .filter_by(company_id=journal.company_id, code=line.account_code)
                .first()
            )
        if not acc:
            continue
        # Assets / expenses increase on debit; liabilities / equity / revenue on credit
        delta = (float(line.debit or 0) - float(line.credit or 0)) * sign
        # For liability/equity/revenue, net credit increases balance in our UI convention
        if acc.account_type in ("Liabilities", "Equity", "Revenue"):
            delta = (float(line.credit or 0) - float(line.debit or 0)) * sign
        acc.balance = float(acc.balance or 0) + delta
