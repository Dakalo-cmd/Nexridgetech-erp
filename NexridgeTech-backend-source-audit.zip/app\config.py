from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    database_url: str = "sqlite:///./nexridge_erp.db"
    secret_key: str = "nexridge-dev-secret-change-in-production"
    access_token_expire_minutes: int = 480
    cors_origins: str = "*"
    algorithm: str = "HS256"

    class Config:
        env_file = ".env"
        extra = "ignore"


@lru_cache
def get_settings() -> Settings:
    return Settings()
